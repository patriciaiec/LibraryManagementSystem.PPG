﻿Imports MySql.Data.MySqlClient

Public Class Returned
    Private Sub LoadData1()
        ' Create a new connection and data adapter specifically for this method

        Dim localDa As New MySqlDataAdapter()
        Dim localTable As New DataTable()

        Try
            ' Ensure the connection is open
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If

            ' Set up the SQL query and data adapter
            Dim sql As String = "SELECT * FROM issue"
            localDa = New MySqlDataAdapter(sql, con)
            localDa.Fill(localTable)

            ' Set the DataSource for the DataGridView
            DataGridViewissue.DataSource = localTable
        Catch ex As MySqlException
            MessageBox.Show("Database error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MessageBox.Show("An unexpected error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ' Ensure the connection is closed after the operation
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        End Try
    End Sub

    Private Sub LoadData()
        ' Create a new connection and data adapter specifically for this method

        Dim localDa As New MySqlDataAdapter()
        Dim localTable As New DataTable()

        Try
            ' Ensure the connection is open
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If

            ' Set up the SQL query and data adapter
            Dim sql As String = "SELECT * FROM `return`"
            localDa = New MySqlDataAdapter(sql, con)
            localDa.Fill(localTable)

            ' Set the DataSource for the DataGridView
            DataGridViewreturn.DataSource = localTable
        Catch ex As MySqlException
            MessageBox.Show("Database error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MessageBox.Show("An unexpected error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ' Ensure the connection is closed after the operation
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        End Try
    End Sub


    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub Returned_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeConnection()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            ' Create an SQL query to insert a new record into the return table
            Dim sql = "INSERT INTO `return` (`NAME`, `STUDENTID`, `BOOKID`, `BOOKNAME`, `ISSUEDATE`, `RETURNDATE`, `FINE`) " &
                      "VALUES (@name, @studentid, @bookid, @bookname, @issuedate, @returndate, @fine)"
            Dim cmd As New MySqlCommand(sql, con)

            ' Add parameters to the command to prevent SQL injection
            cmd.Parameters.AddWithValue("@name", txtname.Text)
            cmd.Parameters.AddWithValue("@studentid", txtstudentid.Text)
            cmd.Parameters.AddWithValue("@bookid", txtbookid.Text)
            cmd.Parameters.AddWithValue("@bookname", txtbookname.Text)
            cmd.Parameters.AddWithValue("@issuedate", DateTimePickerissuedate.Text)
            cmd.Parameters.AddWithValue("@returndate", DateTimePickerreturndate.Text)
            cmd.Parameters.AddWithValue("@fine", txtfine.Text)

            ' Open the connection
            con.Open()

            ' Execute the query
            cmd.ExecuteNonQuery()

            ' Show success message
            MessageBox.Show("Successfully added record.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Clear the textboxes
            txtname.Clear()
            txtstudentid.Clear()
            txtbookid.Clear()
            txtbookname.Clear()
            txtfine.Clear()

            ' Optionally, show the next form or close the current form
            Main.Show()
            Hide()
        Finally
            ' Ensure the connection is closed after the operation
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        End Try

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If DataGridViewissue.SelectedRows.Count > 0 Then
            ' Get the NAME of the selected row
            Dim name As String = DataGridViewissue.SelectedRows(0).Cells("NAME").Value.ToString()

            ' Confirm deletion with the user
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If result = DialogResult.Yes Then
                ' Use a Using block to ensure the command and connection are disposed of properly
                Using cmd As New MySqlCommand("DELETE FROM `return` WHERE `NAME` = @name", con)
                    cmd.Parameters.AddWithValue("@name", name)

                    Try
                        ' Open the connection
                        If con.State = ConnectionState.Closed Then
                            con.Open()
                        End If

                        ' Execute the query to delete the row
                        cmd.ExecuteNonQuery()

                        ' Show a success message
                        MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        ' Refresh the DataGridView
                        LoadData()  ' Call the method to refresh the data in DataGridView
                    Catch ex As MySqlException
                        ' Handle MySQL-specific errors
                        MessageBox.Show("Database error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Catch ex As Exception
                        ' Handle other general errors
                        MessageBox.Show("An unexpected error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End If
        Else
            ' If no row is selected, show an error message
            MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        LoadData1()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Main.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Application.ExitThread()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        LoadData()
    End Sub
End Class
