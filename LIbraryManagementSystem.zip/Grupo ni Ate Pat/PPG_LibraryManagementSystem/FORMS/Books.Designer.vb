﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Books
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Books))
        Label1 = New Label()
        Panel2 = New Panel()
        txtname = New RichTextBox()
        txtauthor = New RichTextBox()
        txtpublisher = New RichTextBox()
        txtprice = New RichTextBox()
        Label4 = New Label()
        txtquantity = New RichTextBox()
        Label3 = New Label()
        Label6 = New Label()
        Button3 = New Button()
        Button2 = New Button()
        Label2 = New Label()
        Label8 = New Label()
        Button1 = New Button()
        Button5 = New Button()
        Label5 = New Label()
        PictureBox1 = New PictureBox()
        PictureBox3 = New PictureBox()
        Panel1 = New Panel()
        DataGridView1 = New DataGridView()
        Label7 = New Label()
        Panel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Bookman Old Style", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.ActiveCaptionText
        Label1.Location = New Point(581, 66)
        Label1.Name = "Label1"
        Label1.Size = New Size(116, 27)
        Label1.TabIndex = 39
        Label1.Text = "Publisher"
        Label1.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(txtname)
        Panel2.Controls.Add(txtauthor)
        Panel2.Controls.Add(txtpublisher)
        Panel2.Controls.Add(txtprice)
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(txtquantity)
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(Label6)
        Panel2.Controls.Add(Button3)
        Panel2.Controls.Add(Button2)
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(Label8)
        Panel2.Controls.Add(Button1)
        Panel2.Location = New Point(52, 49)
        Panel2.Margin = New Padding(3, 2, 3, 2)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1144, 186)
        Panel2.TabIndex = 40
        ' 
        ' txtname
        ' 
        txtname.Location = New Point(45, 95)
        txtname.Margin = New Padding(3, 2, 3, 2)
        txtname.Name = "txtname"
        txtname.Size = New Size(179, 23)
        txtname.TabIndex = 47
        txtname.Text = ""
        ' 
        ' txtauthor
        ' 
        txtauthor.Location = New Point(280, 95)
        txtauthor.Margin = New Padding(3, 2, 3, 2)
        txtauthor.Name = "txtauthor"
        txtauthor.Size = New Size(209, 23)
        txtauthor.TabIndex = 46
        txtauthor.Text = ""
        ' 
        ' txtpublisher
        ' 
        txtpublisher.Location = New Point(557, 95)
        txtpublisher.Margin = New Padding(3, 2, 3, 2)
        txtpublisher.Name = "txtpublisher"
        txtpublisher.Size = New Size(193, 23)
        txtpublisher.TabIndex = 45
        txtpublisher.Text = ""
        ' 
        ' txtprice
        ' 
        txtprice.Location = New Point(822, 95)
        txtprice.Margin = New Padding(3, 2, 3, 2)
        txtprice.Name = "txtprice"
        txtprice.Size = New Size(109, 23)
        txtprice.TabIndex = 44
        txtprice.Text = ""
        ' 
        ' Label4
        ' 
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Bookman Old Style", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = SystemColors.ActiveCaptionText
        Label4.Location = New Point(976, 66)
        Label4.Name = "Label4"
        Label4.Size = New Size(108, 27)
        Label4.TabIndex = 43
        Label4.Text = "Quantity"
        Label4.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' txtquantity
        ' 
        txtquantity.Location = New Point(976, 95)
        txtquantity.Margin = New Padding(3, 2, 3, 2)
        txtquantity.Name = "txtquantity"
        txtquantity.Size = New Size(109, 23)
        txtquantity.TabIndex = 42
        txtquantity.Text = ""
        ' 
        ' Label3
        ' 
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Bookman Old Style", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = SystemColors.ActiveCaptionText
        Label3.Location = New Point(831, 66)
        Label3.Name = "Label3"
        Label3.Size = New Size(82, 27)
        Label3.TabIndex = 41
        Label3.Text = "Price"
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label6
        ' 
        Label6.BackColor = Color.Transparent
        Label6.Font = New Font("Bookman Old Style", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = SystemColors.ActiveCaptionText
        Label6.Location = New Point(438, 9)
        Label6.Name = "Label6"
        Label6.Size = New Size(296, 36)
        Label6.TabIndex = 34
        Label6.Text = "Books Details"
        Label6.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.White
        Button3.FlatStyle = FlatStyle.Popup
        Button3.Font = New Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.ForeColor = SystemColors.HotTrack
        Button3.Location = New Point(654, 146)
        Button3.Margin = New Padding(3, 2, 3, 2)
        Button3.Name = "Button3"
        Button3.Size = New Size(128, 26)
        Button3.TabIndex = 28
        Button3.Text = "Delete"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.White
        Button2.FlatStyle = FlatStyle.Popup
        Button2.Font = New Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = SystemColors.HotTrack
        Button2.Location = New Point(335, 146)
        Button2.Margin = New Padding(3, 2, 3, 2)
        Button2.Name = "Button2"
        Button2.Size = New Size(128, 26)
        Button2.TabIndex = 27
        Button2.Text = "Reload"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Label2
        ' 
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Bookman Old Style", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = SystemColors.ActiveCaptionText
        Label2.Location = New Point(88, 66)
        Label2.Name = "Label2"
        Label2.Size = New Size(82, 27)
        Label2.TabIndex = 16
        Label2.Text = "Name"
        Label2.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label8
        ' 
        Label8.BackColor = Color.Transparent
        Label8.Font = New Font("Bookman Old Style", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.ForeColor = SystemColors.ActiveCaptionText
        Label8.Location = New Point(335, 66)
        Label8.Name = "Label8"
        Label8.Size = New Size(92, 27)
        Label8.TabIndex = 18
        Label8.Text = "Author"
        Label8.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.White
        Button1.FlatStyle = FlatStyle.Popup
        Button1.Font = New Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = SystemColors.HotTrack
        Button1.Location = New Point(493, 146)
        Button1.Margin = New Padding(3, 2, 3, 2)
        Button1.Name = "Button1"
        Button1.Size = New Size(128, 26)
        Button1.TabIndex = 26
        Button1.Text = "Save"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.White
        Button5.FlatStyle = FlatStyle.Popup
        Button5.Font = New Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.ForeColor = SystemColors.HotTrack
        Button5.Location = New Point(578, 509)
        Button5.Margin = New Padding(3, 2, 3, 2)
        Button5.Name = "Button5"
        Button5.Size = New Size(128, 26)
        Button5.TabIndex = 39
        Button5.Text = "Back"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Label5
        ' 
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Bookman Old Style", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = SystemColors.ActiveCaptionText
        Label5.Location = New Point(61, 2)
        Label5.Name = "Label5"
        Label5.Size = New Size(135, 35)
        Label5.TabIndex = 6
        Label5.Text = "Books"
        Label5.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(3, 2)
        PictureBox1.Margin = New Padding(3, 2, 3, 2)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(53, 35)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 15
        PictureBox1.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.White
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(1188, 2)
        PictureBox3.Margin = New Padding(3, 2, 3, 2)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(38, 35)
        PictureBox3.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox3.TabIndex = 14
        PictureBox3.TabStop = False
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.White
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(PictureBox3)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Margin = New Padding(3, 2, 3, 2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1231, 40)
        Panel1.TabIndex = 36
        ' 
        ' DataGridView1
        ' 
        DataGridView1.BackgroundColor = Color.White
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(52, 285)
        DataGridView1.Margin = New Padding(3, 2, 3, 2)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.Size = New Size(1144, 220)
        DataGridView1.TabIndex = 38
        ' 
        ' Label7
        ' 
        Label7.BackColor = Color.Transparent
        Label7.Font = New Font("Bookman Old Style", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.ForeColor = SystemColors.ActiveCaptionText
        Label7.Location = New Point(489, 245)
        Label7.Name = "Label7"
        Label7.Size = New Size(296, 29)
        Label7.TabIndex = 37
        Label7.Text = "Books List"
        Label7.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Books
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.HotTrack
        ClientSize = New Size(1231, 540)
        Controls.Add(Panel2)
        Controls.Add(Button5)
        Controls.Add(Panel1)
        Controls.Add(DataGridView1)
        Controls.Add(Label7)
        FormBorderStyle = FormBorderStyle.None
        Margin = New Padding(3, 2, 3, 2)
        Name = "Books"
        Text = "Books"
        Panel2.ResumeLayout(False)
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents RichTextBox3 As RichTextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents RichTextBox2 As RichTextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label7 As Label
    Friend WithEvents RichTextBox4 As RichTextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtquantity As RichTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtname As RichTextBox
    Friend WithEvents txtauthor As RichTextBox
    Friend WithEvents txtpublisher As RichTextBox
    Friend WithEvents txtprice As RichTextBox
End Class
