﻿Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Relational

Public Class LogIn
    Private Sub LogIn_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeConnection()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click

        Try
            ' Create an SQL query to insert a new record into the account_student table
            Dim sql As String = "INSERT INTO login (`USERNAME`, `PASSWORD`) VALUES (@username, @password)"
            Dim cmd As New MySqlCommand(sql, con)

            ' Add parameters to the command to prevent SQL injection
            cmd.Parameters.AddWithValue("@username", txtUsername.Text)
            cmd.Parameters.AddWithValue("@password", txtPassword.Text)

            ' Open the connection
            con.Open()

            ' Execute the query
            cmd.ExecuteNonQuery()

            ' Show success message
            MessageBox.Show("Successfully added record.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Clear the textboxes
            txtUsername.Clear()
            txtPassword.Clear()

            ' Optionally, show the next form or close the current form
            Main.Show()
            Me.Hide()
        Finally

        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnLogIn.Click
        ' Create the SQL query with parameters, using BINARY for case-sensitivity
        Dim sql As String = "SELECT * FROM login WHERE BINARY `USERNAME` = @username AND BINARY `PASSWORD` = @password"

        ' Create a MySQL command object
        Dim cmd As New MySqlCommand(sql, con)

        ' Add parameters to the command to prevent SQL injection
        cmd.Parameters.AddWithValue("@username", txtUsername.Text)
        cmd.Parameters.AddWithValue("@password", txtPassword.Text)

        Try
            ' Open the connection
            con.Open()

            ' Execute the query
            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            ' Process the data as needed
            If reader.HasRows Then
                ' Logic if data is found (login successful)
                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Logic to move to the next form
                Main.Show()
                Me.Hide()
                con.Close()
            Else
                ' Logic if no data is found (invalid username/password)
                MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                con.Close()

            End If
        Finally
        End Try
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Librarians.Show()
        Me.Hide()
    End Sub
End Class