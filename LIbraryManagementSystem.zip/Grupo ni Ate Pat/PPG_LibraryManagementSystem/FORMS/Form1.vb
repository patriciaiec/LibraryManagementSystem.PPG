﻿Public Class Form1
    Private Sub Panel5_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Panel6.Width += 3
        If Panel6.Width >= 739 Then
            Timer1.Stop()

            Me.Hide()
            LogIn.Show()
        End If
    End Sub
End Class