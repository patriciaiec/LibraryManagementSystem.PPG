﻿Imports MySql.Data.MySqlClient

Public Class StudentsForm
    Private Sub LoadData()
        Try
            ' Ensure the connection is open
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim sql As String = "SELECT * FROM student"
            da = New MySqlDataAdapter(sql, con)
            Table = New DataTable()
            da.Fill(Table)
            DataGridView1.DataSource = Table
        Catch ex As MySqlException
            MessageBox.Show("Database error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MessageBox.Show("An unexpected error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ' Ensure the connection is closed after the operation
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        End Try
    End Sub
    Private Sub StudentsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeConnection()

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            ' Create an SQL query to insert a new record into the account_student table
            Dim sql = "INSERT INTO student (`NAME`, `DEPARTMENT`, `SEMESTER`, `PHONE`) VALUES (@name, @department, @semester, @phone)"
            Dim cmd As New MySqlCommand(sql, con)

            ' Add parameters to the command to prevent SQL injection
            cmd.Parameters.AddWithValue("@name", txtname.Text)
            cmd.Parameters.AddWithValue("@department", txtdepartment.Text)
            cmd.Parameters.AddWithValue("@semester", ComboBoxsemester.Text)
            cmd.Parameters.AddWithValue("@phone", txtphone.Text)

            ' Open the connection
            con.Open()

            ' Execute the query
            cmd.ExecuteNonQuery()

            ' Show success message
            MessageBox.Show("Successfully added record.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Clear the textboxes
            txtname.Clear()
            txtdepartment.Clear()
            ComboBoxsemester.SelectedIndex = -1
            txtphone.Clear()

            ' Optionally, show the next form or close the current form
            Main.Show()
            Hide()
            con.Close()
        Finally

        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            ' Get the REGISTRATION NUMBER of the selected row
            Dim name As String = DataGridView1.SelectedRows(0).Cells("NAME").Value.ToString()

            ' Confirm deletion with the user
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If result = DialogResult.Yes Then
                ' Use a Using block to ensure the command and connection are disposed of properly

                Using cmd As New MySqlCommand("DELETE FROM student WHERE `NAME` = @name", con)
                    cmd.Parameters.AddWithValue("@name", name)

                    Try
                        ' Open the connection
                        If con.State = ConnectionState.Closed Then
                            con.Open()
                        End If

                        ' Execute the query to delete the row
                        cmd.ExecuteNonQuery()

                        ' Show a success message
                        MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        ' Refresh the DataGridView
                        LoadData()  ' Call the method to refresh the data in DataGridView
                    Catch ex As MySqlException
                        ' Handle MySQL-specific errors
                        MessageBox.Show("Database error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Catch ex As Exception
                        ' Handle other general errors
                        MessageBox.Show("An unexpected error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using

            End If
        Else
            ' If no row is selected, show an error message
            MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        LoadData()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Main.Show()
        Me.Hide()

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Application.ExitThread()
    End Sub
End Class